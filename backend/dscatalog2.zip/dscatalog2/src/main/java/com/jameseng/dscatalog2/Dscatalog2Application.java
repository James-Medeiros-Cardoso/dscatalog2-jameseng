package com.jameseng.dscatalog2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dscatalog2Application {

	public static void main(String[] args) {
		SpringApplication.run(Dscatalog2Application.class, args);
	}

}
